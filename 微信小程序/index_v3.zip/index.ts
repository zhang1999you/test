interface JoyConfig {
  centerX: number;
  centerY: number;
  maxR: number;
}

interface MsgItem {
  time: string;
  text: string;
}

interface PlotSample {
  angleAcc: number;
  angleGyro: number;
  angle: number;
}

Page({
  data: {
    stickX: 0,
    stickY: 0,
    speed: 0,
    turn: 0,

    devices: [] as any[],
    isScanning: false,
    connected: false,
    statusMsg: '蓝牙未连接',

    receivedMsgs: [] as MsgItem[],
    isReceiving: true,

    runFlag: 0,
    angleAccOffset: 0,

    anglePID: {
      kp: 5.9,
      ki: 5.1,
      kd: 6.7
    },

    speedPID: {
      kp: 0.0,
      ki: 0.0,
      kd: 0.0
    },

    turnPID: {
      kp: 2.0,
      ki: 0.0,
      kd: 0.0
    },

    scrollIntoViewId: '',

    plotCanvasW: 0,
    plotCanvasH: 0,

    plotShowAcc: true,
    plotShowGyro: true,
    plotShowAngle: true,
    plotCurrentText: '等待 Plot 数据...'
  },

  _joyConfig: { centerX: 0, centerY: 0, maxR: 120 } as JoyConfig,
  _lastSendTime: 0,

  _deviceId: '',
  _serviceId: '',
  _characteristicId: '',

  _rxBuffer: '',
  _pendingLogs: [] as MsgItem[],
  _flushTimer: 0 as any,
  _bleValueChangeHandler: null as any,

  _plotSamples: [] as PlotSample[],
  _plotDrawTimer: 0 as any,
  _plotMaxPoints: 100,

  onReady() {
    this.initJoystick();
    this.initPlotCanvasSize();
  },

  onUnload() {
    this.closeBLE();
  },

  onTouchStart() {},

  initJoystick() {
    wx.createSelectorQuery()
      .select('#joy-base')
      .boundingClientRect((rect: any) => {
        if (rect) {
          this._joyConfig = {
            centerX: rect.left + rect.width / 2,
            centerY: rect.top + rect.height / 2,
            maxR: rect.width / 2.2
          };
        }
      })
      .exec();
  },

  initPlotCanvasSize() {
    const sys = wx.getSystemInfoSync();
    const rpxToPx = sys.windowWidth / 750; // 获取 rpx 转 px 的精确比例

    // 对应 less 中 .plot-container 的 width: 96% 和 padding: 14rpx
    const containerWidthPx = sys.windowWidth * 0.96;
    const paddingPx = 14 * 2 * rpxToPx;
    const w = Math.floor(containerWidthPx - paddingPx);
    
    // 对应 less 中 .plot-canvas 的 height: 320rpx
    const h = Math.floor(320 * rpxToPx);

    this.setData(
      {
        plotCanvasW: w,
        plotCanvasH: h
      },
      () => {
        this.drawPlotChart();
      }
    );
  },

  onTouchMove(e: any) {
    const touch = e.touches[0];

    let dx = touch.clientX - this._joyConfig.centerX;
    let dy = touch.clientY - this._joyConfig.centerY;

    const distance = Math.sqrt(dx * dx + dy * dy);

    if (distance > this._joyConfig.maxR) {
      dx = (dx / distance) * this._joyConfig.maxR;
      dy = (dy / distance) * this._joyConfig.maxR;
    }

    const speed = Math.round((-dy / this._joyConfig.maxR) * 100);
    const turn = Math.round((dx / this._joyConfig.maxR) * 100);

    this.setData({
      stickX: dx,
      stickY: dy,
      speed,
      turn
    });

    this.throttleSendData(speed, turn);
  },

  onTouchEnd() {
    this.setData({
      stickX: 0,
      stickY: 0,
      speed: 0,
      turn: 0
    });

    this.sendToCar(0, 0);
  },

  throttleSendData(speed: number, turn: number) {
    const now = Date.now();

    if (now - this._lastSendTime > 60) {
      this.sendToCar(speed, turn);
      this._lastSendTime = now;
    }
  },

  sendToCar(speed: number, turn: number) {
    if (!this.data.connected) return;

    const buffer = new ArrayBuffer(4);
    const dataView = new DataView(buffer);

    dataView.setUint8(0, 0xAA);
    dataView.setUint8(1, speed + 100);
    dataView.setUint8(2, turn + 100);
    dataView.setUint8(3, 0x55);

    wx.writeBLECharacteristicValue({
      deviceId: this._deviceId,
      serviceId: this._serviceId,
      characteristicId: this._characteristicId,
      value: buffer
    });
  },

  sendString(str: string) {
    if (!this.data.connected) return;

    const buffer = new ArrayBuffer(str.length);
    const dataView = new DataView(buffer);

    for (let i = 0; i < str.length; i++) {
      dataView.setUint8(i, str.charCodeAt(i));
    }

    wx.writeBLECharacteristicValue({
      deviceId: this._deviceId,
      serviceId: this._serviceId,
      characteristicId: this._characteristicId,
      value: buffer
    });
  },

  toggleReceive() {
    const next = !this.data.isReceiving;
    this.setData({ isReceiving: next });

    wx.showToast({
      title: next ? '已开启接收' : '已停止接收',
      icon: 'none'
    });
  },

  toggleRunFlag() {
    const next = this.data.runFlag ? 0 : 1;
    this.setData({ runFlag: next });
    this.sendString(`runFlag:${next}\r\n`);
  },

  onAngleAccOffsetChange(e: any) {
    const val = Number(Number(e.detail.value).toFixed(1));
    this.setData({ angleAccOffset: val });
    
    this.sendString(`accOff:${val}\r\n`);
  },

  onPidChange(e: any) {
    const { type, param } = e.currentTarget.dataset;
    const val = Number(e.detail.value.toFixed(1));
    const cmd = `${type}.${param}:${val}\r\n`;
    this.sendString(cmd);
  },

  togglePlotSeries(e: any) {
    const key = e.currentTarget.dataset.key;

    if (key === 'angleAcc') {
      this.setData({ plotShowAcc: !this.data.plotShowAcc });
    } else if (key === 'angleGyro') {
      this.setData({ plotShowGyro: !this.data.plotShowGyro });
    } else if (key === 'angle') {
      this.setData({ plotShowAngle: !this.data.plotShowAngle });
    }

    this.drawPlotChart();
  },

  _parsePlotLine(text: string) {
    const m = text.match(
      /Plot[:：]\s*([+-]?(?:\d+\.?\d*|\.\d+))\s+([+-]?(?:\d+\.?\d*|\.\d+))\s+([+-]?(?:\d+\.?\d*|\.\d+))/i
    );

    if (!m) return null;

    const angleAcc = Number(m[1]);
    const angleGyro = Number(m[2]);
    const angle = Number(m[3]);

    if ([angleAcc, angleGyro, angle].some(v => Number.isNaN(v))) {
      return null;
    }

    return { angleAcc, angleGyro, angle };
  },

  _enqueueLog(line: string, timeStr: string) {
    this._pendingLogs.push({ time: timeStr, text: line });
    this._scheduleFlushLogs();
  },

  _scheduleFlushLogs() {
    if (this._flushTimer) return;

    this._flushTimer = setTimeout(() => {
      this._flushTimer = 0;

      if (this._pendingLogs.length === 0) return;

      const newLogs = this.data.receivedMsgs.concat(this._pendingLogs);
      this._pendingLogs = [];

      const finalLogs = newLogs.length > 80
        ? newLogs.slice(newLogs.length - 80)
        : newLogs;

      const lastIndex = finalLogs.length - 1;

      this.setData({
        receivedMsgs: finalLogs,
        scrollIntoViewId: lastIndex >= 0 ? `log-${lastIndex}` : ''
      });
    }, 80);
  },

  _enqueuePlotSample(sample: PlotSample) {
    this._plotSamples.push(sample);

    if (this._plotSamples.length > this._plotMaxPoints) {
      this._plotSamples = this._plotSamples.slice(-this._plotMaxPoints);
    }

    this.setData({
      plotCurrentText: `当前值  angleAcc=${sample.angleAcc.toFixed(2)}  angleGyro=${sample.angleGyro.toFixed(2)}  angle=${sample.angle.toFixed(2)}`
    });

    this._schedulePlotDraw();
  },

  _schedulePlotDraw() {
    if (this._plotDrawTimer) return;

    this._plotDrawTimer = setTimeout(() => {
      this._plotDrawTimer = 0;
      this.drawPlotChart();
    }, 16); // 修改点：从 60ms 缩短至 16ms，解锁 60 FPS 的极致丝滑运动感
  },

  drawPlotChart() {
    const w = this.data.plotCanvasW;
    const h = this.data.plotCanvasH;
  
    if (!w || !h) return;
  
    const ctx = wx.createCanvasContext('plot-canvas', this);
  
    // 严格定义的留白结构：左侧留出 60px 确保负号、多位小数完全可见
    const left = 60;
    const right = 15;
    const top = 30;
    const bottom = 20;
  
    const plotW = w - left - right;
    const plotH = h - top - bottom;
  
    ctx.clearRect(0, 0, w, h);
  
    // 绘制深黑色专业级背景
    ctx.setFillStyle('#141414');
    ctx.fillRect(0, 0, w, h);
  
    const selected: Array<{
      key: keyof PlotSample;
      label: string;
      color: string;
      enabled: boolean;
    }> = [
      { key: 'angleAcc', label: 'angleAcc', color: '#ff4d4f', enabled: this.data.plotShowAcc },
      { key: 'angleGyro', label: 'angleGyro', color: '#40c057', enabled: this.data.plotShowGyro },
      { key: 'angle', label: 'angle', color: '#4dabf7', enabled: this.data.plotShowAngle }
    ];
  
    const active = selected.filter(s => s.enabled);
  
    if (active.length === 0) {
      ctx.setFillStyle('#888');
      ctx.setFontSize(13);
      ctx.setTextAlign('center');
      ctx.fillText('请选择要显示的曲线', w / 2, h / 2);
      ctx.draw();
      return;
    }
  
    const samples = this._plotSamples;
  
    if (samples.length === 0) {
      ctx.setFillStyle('#888');
      ctx.setFontSize(13);
      ctx.setTextAlign('center');
      ctx.fillText('等待 Plot 数据...', w / 2, h / 2);
      ctx.draw();
      return;
    }
  
    // 1. 动态计算可见视窗内的极值
    let minV = Infinity;
    let maxV = -Infinity;
  
    for (const s of samples) {
      for (const series of active) {
        const v = s[series.key];
        if (v < minV) minV = v;
        if (v > maxV) maxV = v;
      }
    }
  
    if (!isFinite(minV) || !isFinite(maxV)) {
      ctx.draw();
      return;
    }
  
    // 2. 动态调节纵轴区间缓冲
    if (Math.abs(maxV - minV) < 1e-4) {
      maxV += 1.0;
      minV -= 1.0;
    } else {
      const pad = (maxV - minV) * 0.15;
      maxV += pad;
      minV -= pad;
    }
  
    // 3. 【全新升级】绘制十字交叉网格线 (复刻 pyqtgraph showGrid 视觉)
    ctx.setLineWidth(1);
  
    // (A) 横向网格线及 Y 轴动态刻度
    const gridCount = 4; 
    for (let i = 0; i <= gridCount; i++) {
      const ratio = i / gridCount;
      const y = top + plotH - ratio * plotH;
      const currentVal = minV + ratio * (maxV - minV);
  
      ctx.setStrokeStyle(i === 0 || i === gridCount ? '#333333' : '#222222');
      ctx.beginPath();
      ctx.moveTo(left, y);
      ctx.lineTo(left + plotW, y);
      ctx.stroke();
  
      ctx.setTextAlign('right');
      ctx.setTextBaseline('middle');
      ctx.setFontSize(10);
      ctx.setFillStyle('#888888');
      ctx.fillText(currentVal.toFixed(1), left - 8, y);
    }
  
    // (B) 新增：纵向网格线（时间轴参考分度线）
    const xGridCount = 6;
    ctx.setStrokeStyle('#222222');
    for (let j = 1; j < xGridCount; j++) {
      const x = left + (j / xGridCount) * plotW;
      ctx.beginPath();
      ctx.moveTo(x, top);
      ctx.lineTo(x, top + plotH);
      ctx.stroke();
    }
  
    // 绘制主坐标轴边界框
    ctx.setStrokeStyle('#333333');
    ctx.beginPath();
    ctx.moveTo(left, top);
    ctx.lineTo(left, top + plotH);
    ctx.lineTo(left + plotW, top + plotH);
    ctx.stroke();
  
    // 4. 【平滑算法优化】映射并滚动绘制波形数据
    const maxPoints = this._plotMaxPoints;
    const xStep = plotW / (maxPoints - 1); // 固定分母，保持横向物理时间跨度绝对稳定
    const n = samples.length;
  
    const yOf = (v: number) => {
      return top + plotH - ((v - minV) / (maxV - minV)) * plotH;
    };
  
    active.forEach((series) => {
      ctx.setStrokeStyle(series.color);
      ctx.setLineWidth(2);
      ctx.setLineJoin('round'); // 圆滑拐角
      ctx.beginPath();
  
      samples.forEach((s, i) => {
        // (maxPoints - n + i) 实现了数据未满 500 个点时，波形从画布右边缘稳定向左滚入的视觉特效
        const x = left + (maxPoints - n + i) * xStep;
        const y = yOf(s[series.key]);
  
        if (i === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      });
  
      ctx.stroke();
    });
  
    // 5. 顶部动态图例状态渲染
    ctx.setTextAlign('left');
    ctx.setTextBaseline('top');
    ctx.setFontSize(11);
  
    selected.forEach((series, idx) => {
      const xPos = left + idx * 85;
      if (series.enabled) {
        ctx.setFillStyle(series.color);
        ctx.fillRect(xPos, 8, 10, 6);
        ctx.setFillStyle('#cfcfcf');
        ctx.fillText(series.label, xPos + 14, 6);
      } else {
        ctx.setFillStyle('#333333');
        ctx.fillRect(xPos, 8, 10, 6);
        ctx.setFillStyle('#555555');
        ctx.fillText(series.label, xPos + 14, 6);
      }
    });
  
    ctx.draw();
  },

  initReceiveListener() {
    try {
      if (this._bleValueChangeHandler) {
        wx.offBLECharacteristicValueChange(this._bleValueChangeHandler);
      }
    } catch (e) {}

    this._bleValueChangeHandler = (res: any) => {
      if (!this.data.isReceiving) return;

      const chunkText = Array.from(new Uint8Array(res.value))
        .map((b) => String.fromCharCode(b))
        .join('');

      this._rxBuffer += chunkText;

      const parts = this._rxBuffer.split(/\r\n|\n|\r/);
      this._rxBuffer = parts.pop() || '';

      const now = new Date();
      const pad2 = (n: number) => String(n).padStart(2, '0');
      const timeStr =
        `${pad2(now.getHours())}:` +
        `${pad2(now.getMinutes())}:` +
        `${pad2(now.getSeconds())}`;

      for (const part of parts) {
        const text = part.trim();
        if (text.length === 0) continue;

        const plot = this._parsePlotLine(text);
        if (plot) {
          this._enqueuePlotSample(plot);
          continue;
        }

        this._enqueueLog(text, timeStr);
      }
    };

    wx.onBLECharacteristicValueChange(this._bleValueChangeHandler);

    wx.notifyBLECharacteristicValueChange({
      state: true,
      deviceId: this._deviceId,
      serviceId: this._serviceId,
      characteristicId: this._characteristicId
    });
  },

  startConnect() {
    if (this.data.connected) {
      this.closeBLE();
      return;
    }

    wx.openBluetoothAdapter({
      success: () => {
        this.startDiscovery();
      },
      fail: () => {
        wx.showToast({
          title: '请检查蓝牙开关',
          icon: 'none'
        });
      }
    });
  },

  startDiscovery() {
    this.setData({
      isScanning: true,
      devices: []
    });

    wx.startBluetoothDevicesDiscovery({
      success: () => {
        wx.onBluetoothDeviceFound((res) => {
          res.devices.forEach((device) => {
            if (
              (device.name || device.localName) &&
              !this.data.devices.some((d) => d.deviceId === device.deviceId)
            ) {
              this.setData({
                devices: [...this.data.devices, device]
              });
            }
          });
        });
      }
    });
  },

  handleConnect(e: any) {
    const { id: deviceId } = e.currentTarget.dataset;

    wx.stopBluetoothDevicesDiscovery();

    wx.showLoading({
      title: '连接中...'
    });

    wx.createBLEConnection({
      deviceId,
      success: () => {
        this._deviceId = deviceId;
        this.getServiceAndChar(deviceId);
      },
      fail: () => {
        wx.hideLoading();
      }
    });
  },

  getServiceAndChar(deviceId: string) {
    wx.getBLEDeviceServices({
      deviceId,
      success: (res) => {
        const targetService = res.services.find(
          (s) => s.uuid.indexOf('FFE0') !== -1
        );

        const sId = targetService
          ? targetService.uuid
          : res.services[0].uuid;

        this._serviceId = sId;

        wx.getBLEDeviceCharacteristics({
          deviceId,
          serviceId: sId,
          success: (cRes) => {
            const targetChar = cRes.characteristics.find(
              (c) => c.uuid.indexOf('FFE1') !== -1
            );

            const cId = targetChar
              ? targetChar.uuid
              : cRes.characteristics[0].uuid;

            this._characteristicId = cId;

            this.setData({
              connected: true,
              statusMsg: '连接成功',
              isScanning: false
            });

            wx.hideLoading();
            wx.setBLEMTU({
              deviceId: this._deviceId,
              mtu: 128, // 申请 128 字节大包，防止手机底层自动切断分包
              complete: () => {
                // 无论申请成功还是失败，都继续启动监听
                this.initReceiveListener();
                this.drawPlotChart();
              }
            });
            this.initReceiveListener();
            this.drawPlotChart();
          }
        });
      }
    });
  },

  closeBLE() {
    try {
      if (this._bleValueChangeHandler) {
        wx.offBLECharacteristicValueChange(this._bleValueChangeHandler);
      }
    } catch (e) {}

    if (this._deviceId) {
      wx.closeBLEConnection({
        deviceId: this._deviceId
      });
    }

    if (this._flushTimer) {
      clearTimeout(this._flushTimer);
      this._flushTimer = 0;
    }

    if (this._plotDrawTimer) {
      clearTimeout(this._plotDrawTimer);
      this._plotDrawTimer = 0;
    }

    this._rxBuffer = '';
    this._pendingLogs = [];
    this._plotSamples = [];

    this.setData({
      connected: false,
      statusMsg: '蓝牙未连接',
      devices: [],
      receivedMsgs: [],
      scrollIntoViewId: ''
    });

    this.drawPlotChart();
  }
});